from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg


class FigureCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None):
        super(FigureCanvas, self).__init__()
