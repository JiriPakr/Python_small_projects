import matplotlib
matplotlib.use('Qt5Agg')

from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import sys
import numpy as np


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('quadratic_function.ui', self)

        self.figure = self.canvas.figure
        self.axes = self.figure.add_subplot(111)

    def redraw_plot(self):
        self.stackedWidget.setCurrentIndex(not self.stackedWidget.currentIndex())
        try:
            a = float(self.a_input.text())
            b = float(self.b_input.text())
            c = float(self.c_input.text())
        except ValueError as e:
            QMessageBox.critical(self, 'Error', 'Wrong coefficients:\nValueError: '+str(e))
            return
        x = np.linspace(-5, 5, 100)
        y = a*x**2 + b*x + c
        self.axes.clear()
        self.axes.plot(x, y, 'rx-')
        self.axes.grid()
        self.canvas.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec()
