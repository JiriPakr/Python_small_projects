clear all

ann = ANN(0.05);
max_iter = 100;

XY = rand(1000, 2)*2-1;
Z = rastrigin_2d(XY(:,1), XY(:,2));
training_set = [XY, Z];
plot3(XY(:,1), XY(:, 2), Z, 'b.')

loss_history = ann.train(training_set, [], max_iter);
plot(loss_history)

save(['ann_', datestr(now, 'yyyy-mm-dd_HH-MM-SS'), '.mat'], 'ann');
