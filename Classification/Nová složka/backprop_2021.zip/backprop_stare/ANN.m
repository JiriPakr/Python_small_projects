classdef ANN < handle
  properties
    neurons
    x  % input vector
    t  % expected output
    y  % output of network
    learning_rate
  end
  methods
    function self = ANN(learning_rate)  % fixed structure 2-3-1 for now
      self.learning_rate = learning_rate;
      self.x = zeros(1,2);  % inputs
      self.t = 1;  % expected value
      self.neurons = { ...
          Neuron(1, 1), Neuron(1, 2), ... vstupni vrstva
          Neuron(2, 1), Neuron(2, 2), Neuron(2, 3), ... hidden layer
          Neuron(3, 1)
      };
      for i = 1:2
        self.neurons{i}.connect({}, self.neurons(3:5));
      end
      for i = 3:5
        self.neurons{i}.connect(self.neurons(1:2), self.neurons(6));
      end
      self.neurons{6}.connect(self.neurons(3:5), {});
    end
    function y = forward(self)
        for i = 1:length(self.neurons)
          self.neurons{i}.forward(self);
        end
        self.y = self.neurons{6}.y;
        y = self.y;
    end
    
    function [delta_w_all, delta_b_all] = backward(self, apply_weight_delta)
      delta_w_all = {}; delta_b_all = [];  % PRISTE
      
      for ni = length(self.neurons) : -1 : 3
        self.neurons{ni}.update_delta(self);
      end

      for ni = length(self.neurons) : -1 : 3
        [delta_w, delta_b] = self.neurons{ni}.delta_weights(self.learning_rate);
        if apply_weight_delta
          self.neurons{ni}.apply_weight_delta(delta_w, delta_b);
        end
      end
    end
  
    function [loss]=train(self, training_set, test_set, max_iter)
      % [TODO] train + use test data to save best model
      loss = zeros(max_iter, 1);
      for iter = 1:max_iter
        error_y = zeros(1, size(training_set, 1));
        for training_i = 1:size(training_set, 1)
          self.x = training_set(training_i, 1:2);
          self.t = training_set(training_i, 3);
          self.forward();
          self.backward(true);
          error_y(training_i) = sum((self.y - self.t))^2;
        end
        loss(iter) = mean(error_y)/2;
        fprintf('iter: %05d , loss: %f\n', iter, loss(iter));
      end
      
    end
  end
end
