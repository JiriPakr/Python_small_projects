clear all

ann = ANN(0.05);

error_history = [];
y_history = [];

for iter = 1:1000
  ann.forward();
  ann.backward(true);
  y_history = [y_history, y];
  error_y = sum((ann.y - ann.t))^2 / 2;
  % fprintf('error: %f\n', error_y);
  error_history = [error_history, error_y];
end

plot(error_history);
hold on;
plot(y_history);
plot([0, length(y_history)], [ann.t, ann.t]);
hold off;
legend('error', 'y', 't');
