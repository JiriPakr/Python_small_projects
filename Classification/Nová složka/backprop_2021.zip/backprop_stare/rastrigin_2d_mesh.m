[X, Y] = meshgrid(linspace(-1, 1, 50));
Z = rastrigin_2d(X, Y);

meshc(X, Y, Z);