function Z = rastrigin_2d(X, Y)
  A = 4;  n = 2;
  Z = X.^2-A*cos(2*pi*X)  +  Y.^2-A*cos(2*pi*Y);
end
  
