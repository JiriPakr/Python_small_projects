classdef Neuron < handle
  properties
    y  % this neuron output
    w  % weights
    b  % bias
    delta
    output_neurons
    input_neurons
    is_output % neuron is in output layer
    layer_idx
    j  % index in layer
  end
  methods
    function self = Neuron(layer_idx, j)
      self.layer_idx = layer_idx;
      self.j = j;
      self.is_output = false;
      self.b = 0;
      self.y = 0;
    end

    function connect(self, input_neurons, output_neurons)
      self.input_neurons = input_neurons;
      self.output_neurons = output_neurons;
      self.is_output = isempty(output_neurons);
      self.w = rand(1, length(input_neurons));
      self.b = rand();
    end
    
    function forward(self, ann)
      if self.layer_idx == 1  % input layer
        self.y = ann.x(self.j);
      else % other layers
        sWY = 0;
        for i = 1:length(self.input_neurons)
          sWY = sWY + self.w(i) * self.input_neurons{i}.y;
        end
        self.y = activation(sWY + self.b);
      end
    end
    
    function update_delta(self, ann)
      if self.is_output
        self.delta = (self.y-ann.t(self.j)) * self.y*(1-self.y);
      else
        sum_wdelta_L = 0;
        for neuron_l_cell = self.output_neurons
          neuron_l = neuron_l_cell{1};
          wdelta = neuron_l.w(self.j)*neuron_l.delta;
          sum_wdelta_L = sum_wdelta_L + wdelta;
        end
        self.delta = sum_wdelta_L * self.y*(1-self.y);
      end
    end
    
    function [delta_w, delta_b] = delta_weights(self, learning_rate)
      delta_w = zeros(1, length(self.w));
      for i = 1:length(self.input_neurons)
        o_i = self.input_neurons{i}.y;
        delta_w(i) = -learning_rate * o_i * self.delta;
      end
      delta_b = -learning_rate  * self.delta;
    end

    function apply_weight_delta(self, delta_w, delta_b)
      self.w = self.w + delta_w;
      self.b = self.b + delta_b;
    end
  end
end

function y=activation(x)
  y = 1 / (1 + exp(-x));  % sigmoid
end
